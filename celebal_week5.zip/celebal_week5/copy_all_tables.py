from sqlalchemy import create_engine, text
from sqlalchemy.engine import Engine
from sqlalchemy.exc import SQLAlchemyError
import sqlalchemy

# Step 1: Define connection details
user = "root"
password = "Admin@0218"
host = "localhost"
port = "3306"
source_db = "celebal_db"
target_db = "celebal_target"

# Step 2: Create source and target connections
source_engine = create_engine(f"mysql+pymysql://root:Admin%400218@localhost:3306/celebal_db")
target_engine = create_engine(f"mysql+pymysql://root:Admin%400218@localhost:3306/celebal_target")

# Step 3: Start copying
with source_engine.connect() as source_conn, target_engine.begin() as target_conn:
    result = source_conn.execute(text("SHOW TABLES"))
    tables = [row[0] for row in result]

    for table_name in tables:
        print(f"\n📋 Copying table: {table_name}")

        # Step 4: Get table structure
        create_stmt_result = source_conn.execute(text(f"SHOW CREATE TABLE {table_name}")).fetchone()
        create_stmt = create_stmt_result[1].replace(f"`{table_name}`", f"`{table_name}`")
        create_stmt = create_stmt.replace(f"CREATE TABLE", f"CREATE TABLE IF NOT EXISTS")

        try:
            target_conn.execute(text(create_stmt))
            print(f"✅ Table {table_name} structure copied.")
        except SQLAlchemyError as e:
            print(f"❌ Error creating table {table_name}: {e}")
            continue

        # Step 5: Copy data
        try:
            rows = source_conn.execute(text(f"SELECT * FROM {table_name}")).mappings().all()
            print("Rows to copy:", rows)  # Debug print

            if rows:
                columns = rows[0].keys()
                insert_stmt = f"INSERT INTO {table_name} ({', '.join(columns)}) VALUES ({', '.join([f':{col}' for col in columns])})"
                target_conn.execute(text(insert_stmt), rows)
                print(f"✅ Data copied for table {table_name}")
            else:
                print(f"⚠️ No data found in {table_name}")
        except SQLAlchemyError as e:
            print(f"❌ Error copying data for table {table_name}: {e}")
