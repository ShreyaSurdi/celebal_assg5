import pandas as pd
from sqlalchemy import create_engine
import pyarrow as pa
import pyarrow.parquet as pq
import fastavro

# MySQL DB credentials
username = 'root'                 # or your username
password = 'Admin@0218'        # 🔐 replace with your MySQL password
host = 'localhost'
port = 3306
database = 'celebal_db'

# Step 1: Connect to the database
engine = create_engine(f'mysql+pymysql://root:Admin%400218@localhost:3306/celebal_db')
query = "SELECT * FROM employees"
df = pd.read_sql(query, engine)

# Step 2: Export to CSV
df.to_csv('output.csv', index=False)
print("✅ Exported to output.csv")

# Step 3: Export to Parquet
table = pa.Table.from_pandas(df)
pq.write_table(table, 'output.parquet')
print("✅ Exported to output.parquet")

# Step 4: Export to Avro
records = df.to_dict(orient='records')

schema = {
    'doc': 'Employee record',
    'name': 'Employee',
    'namespace': 'example.avro',
    'type': 'record',
    'fields': [
        {'name': 'id', 'type': 'int'},
        {'name': 'name', 'type': 'string'},
        {'name': 'role', 'type': 'string'},
        {'name': 'salary', 'type': 'int'}
    ]
}

with open('output.avro', 'wb') as out_avro:
    fastavro.writer(out_avro, schema, records)

print("✅ Exported to output.avro")
