import schedule
import time
import os

def job():
    print("🔄 Running export script...")
    os.system("python export_formats.py")

# Schedule the job every 1 minute for demo (change to daily/hourly later)
schedule.every(1).minutes.do(job)

print("⏰ Scheduler started. Press Ctrl+C to stop.")
while True:
    schedule.run_pending()
    time.sleep(1)
