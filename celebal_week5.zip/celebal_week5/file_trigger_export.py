import time
import os

trigger_file = "run_export.flag"

while True:
    if os.path.exists(trigger_file):
        print("🚨 Trigger file detected! Running export...")
        os.remove(trigger_file)  # Remove trigger after detection
        os.system("python export_formats.py")
    time.sleep(5)  # Check every 5 seconds
