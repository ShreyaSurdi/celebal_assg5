CREATE DATABASE celebal_target;
USE celebal_target;
SHOW TABLES;
SELECT * FROM employees;

USE celebal_target;
SELECT * FROM employees;




