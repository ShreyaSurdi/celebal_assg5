from sqlalchemy import create_engine, text
from sqlalchemy.exc import SQLAlchemyError

# DB Credentials
user = "root"
password = "Admin@0218"
host = "localhost"
port = "3306"
source_db = "celebal_db"
target_db = "celebal_target"

# Engines
source_engine = create_engine(f"mysql+pymysql://root:Admin%400218@localhost:3306/celebal_db")
target_engine = create_engine(f"mysql+pymysql://root:Admin%400218@localhost:3306/celebal_target")

# Define table and columns to copy
tables_to_copy = {
    "employees": ["id", "name", "salary"]  # SELECT only specific columns
}

with source_engine.connect() as source_conn, target_engine.connect() as target_conn:
    for table, columns in tables_to_copy.items():
        print(f"\n📋 Copying table: {table}, columns: {columns}")

        # Create the target table (if it doesn't exist)
        cols_str = ", ".join(columns)
        rows = source_conn.execute(text(f"SELECT {cols_str} FROM {table}")).mappings().all()

        if rows:
            col_defs = ", ".join([f"`{col}` VARCHAR(255)" for col in columns])  # Simplified type
            create_stmt = f"CREATE TABLE IF NOT EXISTS `{table}` ({col_defs})"
            target_conn.execute(text(create_stmt))
            print(f"✅ Created {table} with selected columns.")
            
            target_conn.execute(text(f"DELETE FROM `{table}`"))


            insert_stmt = f"INSERT INTO `{table}` ({cols_str}) VALUES ({', '.join([f':{col}' for col in columns])})"
            target_conn.execute(text(insert_stmt), rows)
            print(f"✅ Data copied for table {table}")
        else:
            print(f"⚠️ No data found in table {table}")
