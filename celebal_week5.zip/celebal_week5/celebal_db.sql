CREATE DATABASE celebal_db;
USE celebal_db;
CREATE TABLE employees (
    id INT PRIMARY KEY,
    name VARCHAR(50),
    role VARCHAR(50),
    salary INT
);
INSERT INTO employees (id, name, role, salary) VALUES
(1, 'Shreya', 'Intern', 25000),
(2, 'Riya', 'Analyst', 30000),
(3, 'Neha', 'Engineer', 40000),
(4, 'Aarav', 'Developer', 45000),
(5, 'Vihaan', 'Tester', 28000);
USE celebal_db;
SELECT * FROM employees;




